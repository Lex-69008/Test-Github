Mon fichier Readme.txt selon la deuxième version.
